#!/bin/bash

echo "=== MENGUBAH AKSES USER AINUR  ==="

pkill vsftpd

cat > /etc/vsftpd.conf << 'EOF'
listen=YES
listen_ipv6=NO
anonymous_enable=NO
local_enable=YES
write_enable=NO
local_umask=022
dirmessage_enable=YES
use_localtime=YES
xferlog_enable=YES
connect_from_port_20=YES
chroot_local_user=NO
allow_writeable_chroot=YES
secure_chroot_dir=/var/run/vsftpd/empty
pam_service_name=vsftpd
ssl_enable=NO
local_root=/shared
EOF

/usr/sbin/vsftpd /etc/vsftpd.conf &

sleep 3

echo "Konfigurasi vsftpd saat ini:"
grep "write_enable" /etc/vsftpd.conf

echo "Status FTP service:"
netstat -tulpn | grep :21 && echo "✓ FTP service berjalan" || echo "✗ FTP service tidak berjalan"

echo ""
echo "=== AKSEŚ AINUR SEKARANG READ-ONLY ==="
