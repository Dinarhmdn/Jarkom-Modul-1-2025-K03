#!/bin/bash

echo "=== DOWNLOAD FILE DARI GOOGLE DRIVE ==="

apt update && apt install -y wget unzip ftp file

GDRIVE_URL="https://drive.google.com/uc?export=download&id=11ra_yTV_adsPIXeIPMSt0vrxCBZu0r33"
OUTPUT_FILE="/root/ramalan_cuaca.zip"

echo "Mendownload file dari Google Drive..."
echo "URL: $GDRIVE_URL"
wget --no-check-certificate -O "$OUTPUT_FILE" "$GDRIVE_URL"

echo "Mengekstrak file ZIP..."
mkdir -p /root/extracted_files
unzip -o "$OUTPUT_FILE" -d /root/extracted_files/

echo "File yang berhasil diekstrak:"
ls -la /root/extracted_files/