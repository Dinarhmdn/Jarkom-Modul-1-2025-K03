#!/bin/bash

apt update && apt install -y wget unzip

KITAB_URL="https://drive.google.com/uc?export=download&id=11ua2KgBu3MnHEIjhBnzqqv2RMEiJsILY"
KITAB_ZIP="/root/kitab_penciptaan.zip"

wget --no-check-certificate -O "$KITAB_ZIP" "$KITAB_URL"

echo "Mengekstrak Kitab Penciptaan..."
mkdir -p /root/extracted_kitab
unzip -o "$KITAB_ZIP" -d /root/extracted_kitab/ 2>/dev/null

echo "Isi file ZIP:"
find /root/extracted_kitab/ -type f | while read file; do
echo " - $file ($(du -h "$file" | cut -f1))"
done

find /root/extracted_kitab/ -type f | head -1 | xargs -I {} cp {} /shared/kitab_penciptaan.txt