#!/bin/bash

echo "=== ANALISIS PASCA SERANGAN ==="

echo "1. HASIL SERANGAN PING:"
echo "======================="
if [ -f "/root/ping_attack_results.txt" ]; then
    cat /root/ping_attack_results.txt | tail -10
else
    echo "File hasil tidak ditemukan"
fi

echo ""
echo "2. PENGARUH TERHADAP KINERJA ERU:"
echo "================================"

echo "CPU Usage setelah serangan:"
top -bn1 | grep "Cpu(s)" | awk '{print "CPU: " $2 "% user, " $4 "% system, " $8 "% idle"}'

echo ""
echo "Memory Usage setelah serangan:"
free -h | grep -E "Mem|Swap"

echo ""
echo "Network Statistics:"
ip -s link show eth1 | grep -E "RX|TX" | head -4

echo ""
echo "3. ANALISIS PACKET LOSS DAN RTT:"
echo "================================"

if [ -f "/root/ping_attack_results.txt" ]; then
    LOSS_PERCENT=$(grep "packet loss" /root/ping_attack_results.txt | grep -o "[0-9]*%")
    AVG_RTT=$(grep "rtt" /root/ping_attack_results.txt | awk -F'/' '{print $5 " ms"}' 2>/dev/null)
    MIN_RTT=$(grep "rtt" /root/ping_attack_results.txt | awk -F'/' '{print $3 " ms"}' 2>/dev/null)
    MAX_RTT=$(grep "rtt" /root/ping_attack_results.txt | awk -F'/' '{print $7 " ms"}' 2>/dev/null)
    
    echo "Packet Loss: $LOSS_PERCENT"
    echo "RTT Minimum: $MIN_RTT"
    echo "RTT Rata-rata: $AVG_RTT" 
    echo "RTT Maksimum: $MAX_RTT"
    
    echo ""
    echo "4. KESIMPULAN DAMPAK SERANGAN:"
    echo "=============================="
    
    if [ "$LOSS_PERCENT" = "0%" ]; then
        echo "✓ Tidak ada packet loss - Eru masih stabil"
    else
        echo "✗ Terjadi packet loss $LOSS_PERCENT - Eru mengalami gangguan"
    fi
    
    if [ ! -z "$AVG_RTT" ]; then
        RTT_VALUE=$(echo $AVG_RTT | sed 's/ ms//')
        if (( $(echo "$RTT_VALUE > 10" | bc -l 2>/dev/null || echo "0") )); then
            echo "⚠ RTT tinggi ($AVG_RTT) - Kemungkinan ada congestion"
        else
            echo "✓ RTT normal ($AVG_RTT) - Kinerja jaringan baik"
        fi
    fi
fi

echo "=== ANALISIS SELESAI ==="