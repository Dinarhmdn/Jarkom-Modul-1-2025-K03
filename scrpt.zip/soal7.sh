  GNU nano 8.4                                                                                  /root/ftp_setup.sh *                                                                                         #!/bin/bash

pkill vsftpd

apt update -y
apt install -y ftp
apt install -y vsftpd

mkdir -p /shared
chmod 750 /shared
chmod 640 /shared/file_test.txt

cat > /etc/vsftpd.conf << 'EOF'
listen=YES
listen_ipv6=NO
anonymous_enable=NO
local_enable=YES
write_enable=YES
local_umask=022
dirmessage_enable=YES
use_localtime=YES
xferlog_enable=YES
connect_from_port_20=YES
chroot_local_user=NO
secure_chroot_dir=/var/run/vsftpd/empty
pam_service_name=vsftpd
ssl_enable=NO
local_root=/shared
EOF

service vsftpd restart

useradd -m -s /bin/bash ainur 2>/dev/null
echo "ainur:123" | chpasswd

useradd -m -s /bin/bash melkor 2>/dev/null
echo "melkor:123" | chpasswd

chown ainur:ainur /shared
chmod 750 /shared

echo "Ambatukam,ambasing,ambatunat" > /shared/file_test.txt
chown ainur:ainur /shared/file_test.txt

echo "FTP server dengan  sudah berjalan."